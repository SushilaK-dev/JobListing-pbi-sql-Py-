create database JobInd
select * from Job
select top (5) company, round(avg(rating),2) as average_rating from job group by company order by average_rating desc
WITH STEP1 as
(
select location, max_salary,base_salary from Job where max_salary is not null AND base_salary is not null  
)
select location, avg(max_salary) as avg_max_salary, avg(base_salary) as avg_base_salary from STEP1 
group by location having avg(max_salary) >=980000 order by avg_max_salary desc, avg_base_salary desc

Go
CREATE PROCEDURE  Job_Experience 
AS	
BEGIN
	SET NOCOUNT ON;
	UPDATE Job
	SET
		min_exp = CAST(SUBSTRING(experience, 1, CHARINDEX('-', experience) -1) AS INT),
		max_exp = CAST(
					SUBSTRING(experience,
					CHARINDEX('-', experience) + 1,
					CHARINDEX(' ', experience + ' ') - CHARINDEX('-', experience)-1
					) AS INT
				)
	 WHERE CHARINDEX('-', experience) > 0 ;
END
EXEC dbo.JobExperience

GO
CREATE TRIGGER trg_BeforeInsertJob
ON JOB
INSTEAD OF INSERT
AS
BEGIN

	INSERT INTO Job(
	Sno,
	job_title, 
	company, 
	experience,
	min_exp,
	max_exp,
	salary,
	base_salary,
	max_salary,location,jobListed_days_ago,postedIn,rating,reviews_count,details,salary_data_provide_by, posteddate
	)
	Select
	i.Sno,
	i.job_title, 
	i.company, 
	i.experience,
	i.min_exp,
	i.max_exp,
	i.salary,
	i.base_salary,
	i.max_salary,i.location,i.jobListed_days_ago,i.postedIn,i.rating,i.reviews_count,i.details,i.salary_data_provide_by,i.posteddate from inserted i;
	END
	GO

	
CREATE VIEW Complete_Salary_Jobs AS
SELECT job_title,salary, base_salary,max_salary,details from Job
WHERE Salary IS NOT NULL AND base_salary IS NOT NULL AND max_salary IS NOT NULL;



